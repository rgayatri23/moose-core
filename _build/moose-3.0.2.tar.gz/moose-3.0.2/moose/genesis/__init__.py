from _main import write

__all__ = ["write"]